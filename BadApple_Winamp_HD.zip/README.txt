This replaces the existing low quality bad apple script with a much better looking one.
Beware, your CPU will likely beg for mercy since we're decompressing stuff on the fly,
and maki was not designed to do anything like this (who would've guessed ¯\_(ツ)_/¯).

To install simply overwrite the files in your existing WinampXP skin with the ones in this archive.