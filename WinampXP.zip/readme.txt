WinampXP v1.1.1
A Winamp modern skin based on the looks of Windows XP that aims for accuracy.

-----------------------------------------------------------------------------------
INSTALLATION:

To install, simply extract the three folders to your Winamp skin directory.
Olive Green and Silver themes share code from the base WinampXP skin, so they
won't work on their own.
-----------------------------------------------------------------------------------

Made by mirzi - mirzi.6f.sk

Special thanks:

Victhor, the original creator of Winamp Classic Modern, which is the foundation
for this project.

Godron "The1" Freeman, the man behind Winamp 2000 SP4 for giving me a huge head
start with development, and implementing many more cool features, like a
WMP style visualizer.

Version 1.1.1 contains multiple bug fixes from the previous release.

-----------------------------------------------------------------------------------

Maki sources are included, latest preview version can be found on the GitHub page:
https://github.com/mirzi1/WinampXP