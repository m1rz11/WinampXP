#include "lib/std.mi"

System.onScriptLoaded(){
    //yeah
  }
